BUILD THE MACHINE PROGRESS

This is a standalone website.

FILES
- index.html: the full app
- manifest.webmanifest: optional PWA metadata

LOCAL USE
Open index.html in a modern browser.

DEPLOYMENT
Upload the contents of this folder to any static hosting service such as Netlify, Vercel, GitHub Pages, Cloudflare Pages, or your own server.

IMPORTANT
The current app stores progression and nutrition data in the browser's localStorage. That means your data is tied to the browser/device.

For the private owner + read-only viewer system discussed in chat, the next development step is a real backend with authentication and database permissions. Do not treat a front-end-only "viewer mode" as secure access control.
